const express = require('express');

const bodyParser = require('body-parser');
const accounthendler = require('./httphendler/accounthendler');

const app = express();

//***Middleware********* */

app.use(bodyParser.json());
app.use('/', accounthendler);

//*********** */

/* app.get('/', function(req, res){
    res.send('Hello World!');
})
 */

app.listen(3000), () =>{
    console.log('server start');
}




