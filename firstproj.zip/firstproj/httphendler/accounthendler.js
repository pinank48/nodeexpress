

const express   = require('express');
const route = express.Router();

route.get('/users/',(req,res,next)=>{
    res.send({
        'Name': 'Pinank',
        'city': 'Pune',
        'Number': 123456
    })
})

route.get('/users/:id',(req,res,next)=>{
    res.send({
        'Name': 'Pinank',
        'city': 'Pune',
        'Number': 123456,
        'Empid' : req.params.id
    })
})


route.post('/users/',(req,res,next)=> {
    var body = req.body.name;
    res.send({
        body
    })
})

route.get('/Node', function(req, res){
    res.send('Send by Node Route');
})

route.get('/vue', function(req, res){
    res.send('send response by vue');
})

route.get('/', function(req, res){
    res.send('Hello World!');
})

module.exports = route;


